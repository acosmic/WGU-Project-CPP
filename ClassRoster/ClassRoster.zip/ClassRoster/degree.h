#pragma once
enum DegreeProgram {SECURITY, NETWORK, SOFTWARE};